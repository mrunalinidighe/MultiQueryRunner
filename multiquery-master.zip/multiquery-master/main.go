package main

import (
	"github.com/markustenghamn/multiquery/cmd"
)

func main() {
	cmd.Execute()
}
